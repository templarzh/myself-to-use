<?php if (!defined('SYSTEM_ROOT')) { die('Insufficient Permissions'); } 
//核心插件还没上线...占位备用
//echo 'hey gay';
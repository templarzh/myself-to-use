<?php
/**
 * 插件设置页面
 * 在插件列表页面点击设置插件会自动加载此文件
 * 已自动加载云签到UI
 */
if (!defined('SYSTEM_ROOT')) { die('Insufficient Permissions'); } 
global $i;
echo '调试信息：<br/><br/>';
dump($i,true);
?>